height = 255
width = 255
import pygame as pg
import asyncio
screen = pg.display.set_mode((height,width))
screen_size = [height,width]

async def main():
    while True:
        for event in pg.event.get():
            mousex,mousey = pg.mouse.get_pos()
            print(mousex,mousey)
#            mousex = mousex / 5
#            mousey = mousey / 10
            if pg.mouse.get_pressed()[0]:
                color = (mousex,mousey,255)
            else:
                color = (mousex,mousey,0)
            screen.fill(color)
            pg.display.update()
        await asyncio.sleep(0)
asyncio.run(main())